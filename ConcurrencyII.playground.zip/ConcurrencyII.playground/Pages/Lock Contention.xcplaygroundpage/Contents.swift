//: [Previous](@previous)

import Foundation


var sharedResource = 0
let lock = NSLock()
let group = DispatchGroup() //Makes sure we dont do something else unless we are finished
let numberOfIterations = 5//20_000


var startDate = Date()

//Do work
for i in 0..<numberOfIterations {
    group.enter()
    
    //Do an async operation..not going to wait for it to finish on the background Queue
    DispatchQueue.global().async {
        lock.lock()
        print("\(i): sharedResource = \(sharedResource)")
        //Do work with the shared resource here
        sharedResource += 1
        print("\(i): sharedResource = \(sharedResource)")
        lock.unlock()
        group.leave()
    }
    
}
print("Finished")
group.wait() //Ask the group to wait till everything (process)/threads are finished.
print("Finished group waiting")

var endDate = Date()
var elapsedTime = endDate.timeIntervalSinceReferenceDate - startDate.timeIntervalSinceReferenceDate //Give us the time in seconds.

print("Time elapsed for \(numberOfIterations): \(elapsedTime) seconds.")

//--------------------------------------------------------------------------------------

startDate = Date()
//LOCKs take time to use

let q = DispatchQueue(label: "Shared Access Queue")
//FIFO: First in first out = Line in grocery store

sharedResource = 0

for _ in 0..<numberOfIterations {
    group.enter()
    
    q.async { //Main thread.
        sharedResource += 1
        group.leave()
    }
}

group.wait()
print("count: \(sharedResource)")

endDate = Date()
elapsedTime = endDate.timeIntervalSinceReferenceDate - startDate.timeIntervalSinceReferenceDate //Give us the time in seconds.
print("Using Queue to manage access")
print("Time elapsed for \(numberOfIterations): \(elapsedTime) seconds.")


//: [Next](@next)
