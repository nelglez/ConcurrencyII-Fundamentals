import UIKit

var x = 42 //Shared resource

let xLock = NSLock()

DispatchQueue.concurrentPerform(iterations: 100) { iteration in
    xLock.lock()
    var localCopy = x //READ
    print("iteration: \(iteration): READ \(localCopy)")
    
    localCopy += 1 //DO WORK
    
    x = localCopy //WRITE
    print("iteration: \(iteration): WRITE \(localCopy)")
   xLock.unlock()
}

print("x: ", x)
/*
for iteration in 0..<100 { //Synchronous iterations
 
    var localCopy = x //READ
    print("iteration: \(iteration): READ \(localCopy)")
    
    localCopy += 1 // DO WORK
    
    x = localCopy //WRITE
    print("iteration: \(iteration): WRITE \(localCopy)")
 
}

print("x: ", x)
*/


var sharedResource = 40
let lock = NSLock()

extension NSLock {

    func withLock(_ work:() -> Void) {
        lock()
        work()
        unlock()
    }
}

DispatchQueue.concurrentPerform(iterations: 100) { (iteration) in
    lock.withLock {
        print("Executing thead: \(iteration)")
        var copyOfResource = sharedResource
        copyOfResource += 1
        sharedResource = copyOfResource
    }
}

print("SharedResource: \(sharedResource)")


func doWork() -> Bool {
    lock.lock()
    sharedResource *= 10
    lock.unlock()
    
    lock.lock()
    if sharedResource < 1000 {
        lock.unlock()
        return false
    } else {
        lock.unlock()
        return true
    }
    
}


